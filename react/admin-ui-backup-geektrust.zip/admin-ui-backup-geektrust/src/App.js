import React from "react";
import ViewUsersList from "./components/ViewUsersList";

function App(){
    return (
        <div className="text-lg">
            <ViewUsersList />
        </div>
    )   
}
export default App;